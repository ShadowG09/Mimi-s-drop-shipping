
function orderNow(category) {
    const phone = '08061319406';
    const message = `Hello, I'm interested in ordering from the ${category} category.`;
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.location.href = url;
}
